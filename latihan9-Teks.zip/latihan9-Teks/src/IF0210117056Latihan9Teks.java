/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Firman Ardhiansyah
 */
public class IF0210117056Latihan9Teks {

    public static void main(String[] args) {
        char c;
        char tab = '\t';
        char newline = '\n';
        c = 'A';
        System.out.println("Hasil" + newline + "Char: " + tab + "berisi " + c);
        
    }
    
}
